package com.learning.roboticsprogram;

public interface ShoeAppConstants {

    String SERIALIZABLE_HISTORY = "history";
}
