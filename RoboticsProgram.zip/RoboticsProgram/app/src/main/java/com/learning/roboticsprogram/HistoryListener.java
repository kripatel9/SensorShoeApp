package com.learning.roboticsprogram;

public interface HistoryListener {
    void onHistoryClicked(History history, int position);
}
