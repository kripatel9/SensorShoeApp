package com.learning.roboticsprogram;

import com.learning.roboticsprogram.room.entity.Shoe;

public interface ShoeListener {
    void onShoeSaved(Shoe shoe);
}
