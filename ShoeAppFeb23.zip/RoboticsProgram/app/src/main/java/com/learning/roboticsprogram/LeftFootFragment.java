package com.learning.roboticsprogram;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.learning.roboticsprogram.room.entity.Shoe;

public class LeftFootFragment extends Fragment {
    TextView reading1_L;
    TextView reading2_L;
    TextView reading3_L;
    TextView reading4_L;
    TextView status_left;
    Shoe shoe;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.shoe_back_activity_left, container, false);
        reading1_L = (TextView) view.findViewById(R.id.reading1_L);
        reading2_L = (TextView) view.findViewById(R.id.reading2_L);
        reading3_L = (TextView) view.findViewById(R.id.reading3_L);
        reading4_L = (TextView) view.findViewById(R.id.reading4_L);
        status_left = (TextView) view.findViewById(R.id.status_left);
        if (shoe != null) {
            String stringDoubleL1 = Double.toString(shoe.getL1());
            reading1_L.setText(stringDoubleL1);

            String stringDoubleL2 = Double.toString(shoe.getL2());
            reading2_L.setText(stringDoubleL2);

            String stringDoubleL3 = Double.toString(shoe.getL3());
            reading3_L.setText(stringDoubleL3);

            String stringDoubleL4 = Double.toString(shoe.getL4());
            reading4_L.setText(stringDoubleL4);

            if (shoe.getStatusLeft() == 1) {
                status_left.setText(R.string.statusGood);
            }else if (shoe.getStatusLeft() == 2) {
                status_left.setText(R.string.statusOk);
            }else
                status_left.setText(R.string.statusBad);
        }
        return view;
    }

    public void setShoe(Shoe shoe) {
        this.shoe = shoe;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);

    }
}