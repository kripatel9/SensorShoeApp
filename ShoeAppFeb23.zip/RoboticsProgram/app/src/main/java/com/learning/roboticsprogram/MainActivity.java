package com.learning.roboticsprogram;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.facebook.stetho.Stetho;
import com.learning.roboticsprogram.room.database.AppDatabase;
import com.learning.roboticsprogram.room.entity.Shoe;

public class MainActivity extends AppCompatActivity {
    RelativeLayout side_view_layout;
    RelativeLayout bottom_view_layout;
    RelativeLayout history_view_layout;

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Stetho.initializeWithDefaults(this);

        bottom_view_layout = findViewById(R.id.bottom_view_layout);
        history_view_layout = findViewById(R.id.history_view_layout);

        saveShoe();

        bottom_view_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), ShoeBottomActivityLR.class);
                startActivity(intent);
            }
        });

        history_view_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), HistoryActivity.class);
                startActivity(intent);
            }
        });

        getWindow().setStatusBarColor(ContextCompat.getColor(MainActivity.this, R.color.darkRed));
        getSupportActionBar().setTitle("Dashboard");
    }


    private void saveShoe() {
        final Shoe shoe = new Shoe();
        shoe.setDateTime(System.currentTimeMillis());
        shoe.setL1(3);
        shoe.setL2(5);
        shoe.setL3(9);
        shoe.setL4(7);
        shoe.setR1(6);
        shoe.setR2(7);
        shoe.setR3(8);
        shoe.setR4(2);
        shoe.setStatusLeft(1);
        shoe.setStatusRight(3);
        shoe.setStepGoal(8000);
        shoe.setStepCount(4000);

        @SuppressLint("StaticFieldLeak")
        class SaveShoeTask extends AsyncTask<Void, Void, Void> {

            @Override
            protected Void doInBackground(Void... voids) {
                AppDatabase.getDatabase(getApplicationContext()).appDao().insertShoe(shoe);
                return null;
            }
        }
        new SaveShoeTask().execute();
    }
}