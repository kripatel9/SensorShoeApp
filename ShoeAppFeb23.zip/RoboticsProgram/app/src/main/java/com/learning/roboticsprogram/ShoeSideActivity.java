package com.learning.roboticsprogram;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;

public class ShoeSideActivity extends AppCompatActivity {

    Button bottom_view_btn;
    Button history_btn;
    Button leftRight_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.shoe_side_activity_layout);

        bottom_view_btn = findViewById(R.id.bottom_view_btn);
        history_btn = findViewById(R.id.history_btn);

        bottom_view_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ShoeSideActivity.this, ShoeBottomActivityLR.class);
                startActivity(intent);
            }
        });


        history_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), HistoryActivity.class);
                startActivity(intent);
            }
        });

        getWindow().setStatusBarColor(ContextCompat.getColor(ShoeSideActivity.this, R.color.darkRed));
        getSupportActionBar().setTitle("Status");
    }
}

