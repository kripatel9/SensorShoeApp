package com.learning.roboticsprogram;

import android.annotation.SuppressLint;
import android.os.AsyncTask;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.learning.roboticsprogram.room.database.AppDatabase;
import com.learning.roboticsprogram.room.entity.Shoe;

import java.util.ArrayList;
import java.util.List;

public class HistoryActivity extends AppCompatActivity {
    public static final String TAG = "HistoryActivity";

    HistoryFragment historyFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.history_activity_layout);

        historyFragment = new HistoryFragment(this);

        getSupportFragmentManager().beginTransaction()
                .replace(R.id.recyclerListContainer, historyFragment)
                .commit();

        getWindow().setStatusBarColor(ContextCompat.getColor(HistoryActivity.this, R.color.darkRed));
        getSupportActionBar().setTitle("History");

       // getShoe();
    }

   /* private void getShoe() {
        @SuppressLint("StaticFieldLeak")
        class GetShoeTask extends AsyncTask<Void, Void, Shoe> {

            @Override
            protected Shoe doInBackground(Void... voids) {
                return AppDatabase
                        .getDatabase(getApplicationContext())
                        .appDao().getShoe(1);
            }

            @Override
            protected void onPostExecute(Shoe shoe) {
                System.out.println("onPostExecute getShoe****** " + shoe);
                historyFragment.setShoe(shoe);
            }
        }
        new GetShoeTask().execute();
    }*/
}