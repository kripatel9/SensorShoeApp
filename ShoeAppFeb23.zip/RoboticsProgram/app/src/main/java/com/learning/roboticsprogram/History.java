package com.learning.roboticsprogram;

import java.io.Serializable;

public class History implements Serializable {

    private String date;
    private String time;
    private String thumbnail;
    private int stepCnt;
    private int stepGoal;
    private double reading1;
    private double reading2;

    public History(String date, String time, int stepCnt, int stepGoal) {
        this.date = date;
        this.time = time;
        this.stepCnt = stepCnt;
        this.stepGoal = stepGoal;
    }

    public void setStepCnt(int stepCnt) {
        this.stepCnt = stepCnt;
    }

    public int getStepCnt() {
        return stepCnt;
    }

    public void setStepGoal(int stepGoal) {
        this.stepGoal = stepGoal;
    }

    public int getStepGoal() {
        return stepGoal;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getThumbnail() {
        return thumbnail;
    }

    public void setThumbnail(String thumbnail) {
        this.thumbnail = thumbnail;
    }
}
