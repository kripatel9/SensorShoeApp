package com.learning.roboticsprogram;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.learning.roboticsprogram.room.database.AppDatabase;
import com.learning.roboticsprogram.room.entity.Shoe;

import java.util.ArrayList;
import java.util.List;

import static com.learning.roboticsprogram.ShoeAppConstants.SERIALIZABLE_HISTORY;

public class HistoryFragment extends Fragment implements HistoryListener {

    Shoe shoe;
    private RecyclerView historyRecyclerView;
    private List<Shoe> historyList;
    private HistoryListAdapter historyListAdapter;
    private Context context;

    public HistoryFragment(Context context) {
        this.context = context;
        System.out.println(" HistoryFragment : ");
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        historyList = new ArrayList<>();
        View v = inflater.inflate(R.layout.history_fragment_layout, container, false);
        System.out.println(" onCreateView : SHOE "+shoe);
        historyListAdapter = new HistoryListAdapter(context, historyList, this);
        initHistoryLayout(v);
        getAllShoes();
        return v;
    }

    private void initHistoryLayout(View v) {
        historyRecyclerView = v.findViewById(R.id.recyclerview_id);
        historyRecyclerView.setLayoutManager(
                new LinearLayoutManager(context)
        );
        historyRecyclerView.setAdapter(historyListAdapter);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onAttach(@NonNull Context context) {
        System.out.println("onAttach: ");
        super.onAttach(context);
    }

    @Override
    public void onHistoryClicked(Shoe shoe, int position) {
        Intent intent = new Intent(this.getActivity(), HistoryInfoActivity.class);
        intent.putExtra(SERIALIZABLE_HISTORY, shoe);
        startActivity(intent);
    }

    private void getAllShoes() {
        @SuppressLint("StaticFieldLeak")
        class GetAllShoesTask extends AsyncTask<Void, Void, List<Shoe>> {

            @Override
            protected List<Shoe> doInBackground(Void... voids) {
                return AppDatabase
                        .getDatabase(getActivity().getApplicationContext())
                        .appDao().getAllShoes();
            }

            @Override
            protected void onPostExecute(List<Shoe> shoes) {
                System.out.println("onPostExecute: " + shoes);
                historyList.clear();
                historyList = shoes;
                historyListAdapter.refresh(historyList);
            }
        }
        new GetAllShoesTask().execute();
    }

}
