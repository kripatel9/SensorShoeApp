package com.learning.roboticsprogram;

import android.icu.text.SimpleDateFormat;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;

import com.learning.roboticsprogram.room.entity.Shoe;

import java.util.Calendar;

public class HistoryRightFootFragment extends Fragment {
    Shoe shoe;
    TextView dateViewRight;
    TextView timeViewRight;
    TextView reading1_R;
    TextView reading2_R;
    TextView reading3_R;
    TextView reading4_R;
    TextView statusRight;
    TextView stepCountRight;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.history_info_layout_right, container, false);
        dateViewRight = (TextView) view.findViewById(R.id.dateViewRight);
        timeViewRight = (TextView) view.findViewById(R.id.timeViewRight);
        reading1_R = (TextView) view.findViewById(R.id.reading1_L);
        reading2_R = (TextView) view.findViewById(R.id.reading2_L);
        reading3_R = (TextView) view.findViewById(R.id.reading3_L);
        reading4_R = (TextView) view.findViewById(R.id.reading4_L);
        statusRight = (TextView) view.findViewById(R.id.statusLeft);
        stepCountRight = (TextView) view.findViewById(R.id.stepCountRight);
        if (shoe != null) {
            String stringDoubleL1 = Double.toString(shoe.getR1());
            reading1_R.setText(stringDoubleL1);

            String stringDoubleL2 = Double.toString(shoe.getR2());
            reading2_R.setText(stringDoubleL2);

            String stringDoubleL3 = Double.toString(shoe.getR3());
            reading3_R.setText(stringDoubleL3);

            String stringDoubleL4 = Double.toString(shoe.getR4());
            reading4_R.setText(stringDoubleL4);

            stepCountRight.setText(Integer.toString(shoe.getStepCount()));

            dateViewRight.setText(getDateTime(shoe.getDateTime(),"MM/dd/yyyy"));

            timeViewRight.setText(getDateTime(shoe.getDateTime(),"KK:mm aa"));

            if (shoe.getStatusRight() == 1) {
                statusRight.setText(R.string.statusGood);
            }else if (shoe.getStatusRight() == 2) {
                statusRight.setText(R.string.statusOk);
            }else
                statusRight.setText(R.string.statusBad);
        }
        return view;
    }

    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
    }

    public void setShoes(Shoe shoe) {
        this.shoe = shoe;
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    public static String getDateTime(long milliSeconds, String dateFormat) {
        SimpleDateFormat formatter = new SimpleDateFormat(dateFormat);

        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(milliSeconds);
        return formatter.format(calendar.getTime());
    }
}
