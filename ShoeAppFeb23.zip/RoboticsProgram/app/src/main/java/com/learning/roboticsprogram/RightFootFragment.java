package com.learning.roboticsprogram;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.learning.roboticsprogram.room.entity.Shoe;

public class RightFootFragment extends Fragment {
    TextView reading1_R;
    TextView reading2_R;
    TextView reading3_R;
    TextView reading4_R;
    TextView status_right;
    Shoe shoe;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.shoe_back_activity_right, container, false);
        reading1_R = (TextView) view.findViewById(R.id.reading1_L);
        reading2_R = (TextView) view.findViewById(R.id.reading2_L);
        reading3_R = (TextView) view.findViewById(R.id.reading3_L);
        reading4_R = (TextView) view.findViewById(R.id.reading4_L);
        status_right = (TextView) view.findViewById(R.id.status_right);
        if (shoe != null) {
            String stringDoubleR1 = Double.toString(shoe.getR1());
            reading1_R.setText(stringDoubleR1);

            String stringDoubleR2 = Double.toString(shoe.getR2());
            reading2_R.setText(stringDoubleR2);

            String stringDoubleR3 = Double.toString(shoe.getR3());
            reading3_R.setText(stringDoubleR3);

            String stringDoubleR4 = Double.toString(shoe.getR4());
            reading4_R.setText(stringDoubleR4);

            if (shoe.getStatusRight() == 1) {
                status_right.setText(R.string.statusGood);
            }else if (shoe.getStatusRight() == 2) {
                status_right.setText(R.string.statusOk);
            }else
                status_right.setText(R.string.statusBad);
        }
        return view;
    }

    public void setShoe(Shoe shoe) {
        this.shoe = shoe;
    }
}
