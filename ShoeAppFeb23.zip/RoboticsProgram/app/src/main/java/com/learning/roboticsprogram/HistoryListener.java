package com.learning.roboticsprogram;

import com.learning.roboticsprogram.room.entity.Shoe;

public interface HistoryListener {
    void onHistoryClicked(Shoe shoe, int position);
}
