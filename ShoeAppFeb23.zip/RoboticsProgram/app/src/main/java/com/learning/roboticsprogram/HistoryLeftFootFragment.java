package com.learning.roboticsprogram;

import android.icu.text.SimpleDateFormat;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;

import com.learning.roboticsprogram.room.entity.Shoe;

import java.util.Calendar;

public class HistoryLeftFootFragment extends Fragment {
    Shoe shoe;
    TextView dateViewLeft;
    TextView timeViewLeft;
    TextView reading1_L;
    TextView reading2_L;
    TextView reading3_L;
    TextView reading4_L;
    TextView statusLeft;
    TextView stepCountLeft;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.history_info_layout_left, container, false);
        dateViewLeft = (TextView) view.findViewById(R.id.dateViewLeft);
        timeViewLeft = (TextView) view.findViewById(R.id.timeViewLeft);
        reading1_L = (TextView) view.findViewById(R.id.reading1_L);
        reading2_L = (TextView) view.findViewById(R.id.reading2_L);
        reading3_L = (TextView) view.findViewById(R.id.reading3_L);
        reading4_L = (TextView) view.findViewById(R.id.reading4_L);
        statusLeft = (TextView) view.findViewById(R.id.statusLeft);
        stepCountLeft = (TextView) view.findViewById(R.id.stepCountLeft);
        if (shoe != null) {
            String stringDoubleL1 = Double.toString(shoe.getL1());
            reading1_L.setText(stringDoubleL1);

            String stringDoubleL2 = Double.toString(shoe.getL2());
            reading2_L.setText(stringDoubleL2);

            String stringDoubleL3 = Double.toString(shoe.getL3());
            reading3_L.setText(stringDoubleL3);

            String stringDoubleL4 = Double.toString(shoe.getL4());
            reading4_L.setText(stringDoubleL4);

            stepCountLeft.setText(Integer.toString(shoe.getStepCount()));

            dateViewLeft.setText(getDateTime(shoe.getDateTime(),"MM/dd/yyyy"));

            timeViewLeft.setText(getDateTime(shoe.getDateTime(),"KK:mm aa"));

            if (shoe.getStatusLeft() == 1) {
                statusLeft.setText(R.string.statusGood);
            }else if (shoe.getStatusLeft() == 2) {
                statusLeft.setText(R.string.statusOk);
            }else
                statusLeft.setText(R.string.statusBad);
        }
        return view;
    }

    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
    }

    public void setShoes(Shoe shoe) {
        this.shoe = shoe;
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    public static String getDateTime(long milliSeconds, String dateFormat) {
        SimpleDateFormat formatter = new SimpleDateFormat(dateFormat);

        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(milliSeconds);
        return formatter.format(calendar.getTime());
    }
}
