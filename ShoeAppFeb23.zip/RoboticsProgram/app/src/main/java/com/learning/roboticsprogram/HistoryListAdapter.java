package com.learning.roboticsprogram;

import android.content.Context;
import android.icu.text.SimpleDateFormat;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.recyclerview.widget.RecyclerView;

import com.learning.roboticsprogram.room.entity.Shoe;

import java.util.Calendar;
import java.util.List;

public class HistoryListAdapter extends RecyclerView.Adapter<HistoryListAdapter.HistoryViewHolder> {

    String date;
    String time;
    private List<Shoe> histories;
    private Context context;
    private HistoryListener historyListener;

    public HistoryListAdapter(Context context, List<Shoe> histories, HistoryListener historyListener) {
        this.histories = histories;
        this.context = context;
        this.historyListener = historyListener;
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    public static String getDate(long milliSeconds, String dateFormat) {
        // Create a DateFormatter object for displaying date in specified format.
        SimpleDateFormat formatter = new SimpleDateFormat(dateFormat);

        // Create a calendar object that will convert the date and time value in milliseconds to date.
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(milliSeconds);
        return formatter.format(calendar.getTime());
    }

    @NonNull
    @Override
    public HistoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        System.out.println(" onCreateViewHolder : ");

        return new HistoryViewHolder(
                LayoutInflater.from(context).inflate(
                        R.layout.history_row,
                        parent,
                        false
                )
        );
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    public void onBindViewHolder(@NonNull HistoryViewHolder holder, final int position) {
        System.out.println(" onBindViewHolder : histories.get(position).getDate()) " + histories);
        date = getDate(histories.get(position).getDateTime(), "MM/dd/yyyy");
        time = getDate(histories.get(position).getDateTime(),"KK:mm aa");

        holder.date.setText(date);
        holder.time.setText(time);
        // holder.time.setText(histories.get(position).getTime());

        holder.item_row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                historyListener.onHistoryClicked(histories.get(position), position);
            }
        });
    }

    public void refresh(List<Shoe> shoes) {
        this.histories = shoes;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        System.out.println(" onBindViewHolder : histories.size()) " + histories.size());
        return histories.size();
    }

    static class HistoryViewHolder extends RecyclerView.ViewHolder {
        TextView date;
        TextView time;
        RelativeLayout item_row;

        HistoryViewHolder(@NonNull View itemView) {
            super(itemView);
            System.out.println(" HistoryViewHolder : setting up fields ");
            date = itemView.findViewById(R.id.dateViewLeft);
            time = itemView.findViewById(R.id.timeViewLeft);
            item_row = itemView.findViewById(R.id.item_row);

        }
    }
}