package com.learning.roboticsprogram;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.CompositePageTransformer;
import androidx.viewpager2.widget.MarginPageTransformer;
import androidx.viewpager2.widget.ViewPager2;

import com.learning.roboticsprogram.room.database.AppDatabase;
import com.learning.roboticsprogram.room.entity.Shoe;

public class ShoeBottomActivityLR extends AppCompatActivity implements AppTasks {
    private static final int NUM_PAGES = 2;
    Button historyBtn;
    AppTasks appTasks;
    LeftFootFragment leftFootFragment;
    RightFootFragment rightFootFragment;
    private ViewPager2 viewPager;
    private FragmentStateAdapter pagerAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.shoe_back_activity_layout_lr);

        appTasks = (AppTasks) this;
        leftFootFragment = new LeftFootFragment();
        rightFootFragment = new RightFootFragment();

        viewPager = findViewById(R.id.view_pager2);
        pagerAdapter = new ShoeBottomAdapter(this);
        viewPager.setAdapter(pagerAdapter);
        viewPager.setClipToPadding(false);
        viewPager.setClipChildren(false);
        viewPager.setOffscreenPageLimit(2);
        viewPager.getChildAt(0).setOverScrollMode(RecyclerView.OVER_SCROLL_NEVER);

        CompositePageTransformer compositePageTransformer = new CompositePageTransformer();
        compositePageTransformer.addTransformer(new MarginPageTransformer(40));
        compositePageTransformer.addTransformer(new ViewPager2.PageTransformer() {
            @Override
            public void transformPage(@NonNull View page, float position) {
                float r = 1 - Math.abs(position);
                page.setScaleY(0.85f + r * 0.15f);
            }
        });
        viewPager.setPageTransformer(compositePageTransformer);


        historyBtn = findViewById(R.id.history_btn2);
        historyBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ShoeBottomActivityLR.this, HistoryActivity.class);
                startActivity(intent);
//                saveShoe();

            }
        });
        getWindow().setStatusBarColor(ContextCompat.getColor(ShoeBottomActivityLR.this, R.color.darkRed));
        getSupportActionBar().setTitle("Status");

        getShoe();
    }

    @Override

    public void onBackPressed() {
        if (viewPager.getCurrentItem() == 0) {
            // If the user is currently looking at the first step, allow the system to handle the
            // Back button. This calls finish() on this activity and pops the back stack.
            super.onBackPressed();
        } else {
            // Otherwise, select the previous step.
            viewPager.setCurrentItem(viewPager.getCurrentItem() - 1);
        }
    }

    private void getShoe() {
        @SuppressLint("StaticFieldLeak")
        class GetShoeTask extends AsyncTask<Void, Void, Shoe> {

            @Override
            protected Shoe doInBackground(Void... voids) {
                return AppDatabase
                        .getDatabase(getApplicationContext())
                        .appDao().getShoe(1);
            }

            @Override
            protected void onPostExecute(Shoe shoe) {
                System.out.println("onPostExecute getShoe****** " + shoe);
                appTasks.onSuccess(shoe);
                leftFootFragment.setShoe(shoe);
                rightFootFragment.setShoe(shoe);
                pagerAdapter.notifyDataSetChanged();
            }
        }
        new GetShoeTask().execute();
    }

    /*private void saveShoe() {
        final Shoe shoe = new Shoe();
        shoe.setDateTime("12/3/20");
        shoe.setL1(4.30);
        shoe.setL2(4.30);
        shoe.setL3(4.30);
        shoe.setL4(4.30);
        shoe.setStatus(1);
        shoe.setStepGoal(4000);

        @SuppressLint("StaticFieldLeak")
        class SaveShoeTask extends AsyncTask<Void, Void, Void> {

            @Override
            protected Void doInBackground(Void... voids) {
                AppDatabase.getDatabase(getApplicationContext()).appDao().insertShoe(shoe);
                return null;
            }
        }
        new SaveShoeTask().execute();
    }*/

    @Override
    public void onSuccess(Shoe shoe) {

    }

    @Override
    public void onFailure() {

    }

    private class ShoeBottomAdapter extends FragmentStateAdapter {
        public ShoeBottomAdapter(FragmentActivity fa) {
            super(fa);
        }

        @Override
        public Fragment createFragment(int position) {
            System.out.println("LeftFootFragment: createFragment: "+position);
            switch (position) {
                case 0:
                    return leftFootFragment;
                case 1:
                    return rightFootFragment;
            }
            return leftFootFragment;
        }

        @Override
        public int getItemCount() {
            return NUM_PAGES;
        }
    }
}
